dust = 70

# dust 변수에 들어 있는 값을 기준으로 미세먼지 수치 정보를 출력해보세요.

if 150 < dust:
    print('매우나쁨')
elif 80 < dust <= 150:
    print('나쁨')
elif 30 < dust and dust <= 80:
    print('보통')
else:
    print('좋음')