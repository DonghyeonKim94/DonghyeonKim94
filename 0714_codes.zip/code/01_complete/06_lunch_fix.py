import random

menu = ['새마을식당', '초원삼겹살', '홍콩비밀반점']

lunch = random.choice(menu)
print(lunch)

# print(f'오늘의 점심은 {lunch}입니다.')