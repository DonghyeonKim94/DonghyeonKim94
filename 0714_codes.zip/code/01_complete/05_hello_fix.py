# hello.py 수정

greeting = '안녕하세요!'

print(greeting)

# while
count = 0 
while count < 4:
    print(greeting)
    count += 1


# for
for i in range(4):
    print(greeting)