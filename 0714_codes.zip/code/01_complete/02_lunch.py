menu = ['새마을식당', '초원삼겹살', '홍콩비밀반점']

print(menu)