greeting = '안녕하세요!'

print(greeting)